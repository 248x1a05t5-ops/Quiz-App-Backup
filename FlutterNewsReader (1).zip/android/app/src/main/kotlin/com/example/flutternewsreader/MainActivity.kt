package com.example.flutternewsreader

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
